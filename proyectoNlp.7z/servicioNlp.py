import spacy
from spacy.matcher import Matcher
nlp = spacy.load("es_core_news_md")
matcher = Matcher(nlp.vocab)

pattern = [{"IS_DIGIT": True}, {"TEXT": "años"}]
matcher.add("EDAD", [pattern])

pattern = [{"TEXT": "DNI"}, {"IS_DIGIT": True}]
matcher.add("DNI", [pattern])

pattern = [
        [{"TEXT": "de"}, {"TEXT": "genero"}, {"TEXT": "femenino"}],
        [{"TEXT": "de"}, {"TEXT": "genero"}, {"TEXT": "masculino"}]
        ]
matcher.add("SEXO", pattern)

pattern = [
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "casado"}],
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "casada"}],
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "viudo"}],
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "viuda"}],
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "divorciado"}],
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "divorciada"}],
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "soltero"}],
            [{"TEXT": "estado"}, {"TEXT": "civil"}, {"TEXT": "de", "OP": "?"}, {"LOWER": "soltera"}],
        ]
matcher.add("CIVIL", pattern)

with open("./textos/datos6.txt", "r") as f:
    text = f.read()

doc = nlp(text)


matches = matcher(doc)

# Matches
for match_id, start, end in matches:

    string_id = nlp.vocab.strings[match_id]

    if string_id == "SEXO":
        matched_span = doc[end - 1:end]
        print("Matcher:", string_id, ":", matched_span.text)
    elif string_id == "CIVIL":
        matched_span = doc[end - 1:end]
        print("Matcher:", string_id, ":", matched_span.text)
    elif string_id == "EDAD":
        matched_span = doc[start:end - 1]
        print("Matcher:", string_id, ":", matched_span.text)
    elif string_id == "DNI":
        matched_span = doc[end - 1:end]
        print("Matcher:", string_id, ":", matched_span.text)
    else:
        matched_span = doc[start:end]
        print("Matcher:", string_id, ":", matched_span.text)


for ent in doc.ents:
    if ent.label_ == "PER":
        print("Estadistico", "Nombre: ", ent.text)
    if ent.label_ == "LOC":
        print("Estadistico", "Procedencia: ", ent.text)
